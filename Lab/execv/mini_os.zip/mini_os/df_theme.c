#include <stdio.h>

void main()
{
  printf("Default Theme Loading.........\n");  
}