#include <stdio.h>

void main()
{
  printf("Screen Saver Loading.........\n");
}