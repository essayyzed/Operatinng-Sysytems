#include <stdio.h>

int main(int ac, char const * const *av)
{
  printf("Mouse Driver Loaded......\n");
  return (0);
}