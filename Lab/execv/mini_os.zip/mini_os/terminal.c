#include <stdio.h>
#include <stdlib.h>

int	main(int argc, char **argv)
{
  


  system("gnome-terminal");
  return 0;
}
