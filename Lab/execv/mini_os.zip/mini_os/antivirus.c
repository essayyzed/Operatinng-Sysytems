#include <stdio.h>

void main()
{
  printf("Antivirus Loading.......\n");
}