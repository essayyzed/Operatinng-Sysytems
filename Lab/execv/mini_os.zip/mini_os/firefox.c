#include <stdio.h>
#include <stdlib.h>

int	main(int argc, char **argv)
{

  system("/usr/bin/firefox www.google.com &");
  return 0;
}
