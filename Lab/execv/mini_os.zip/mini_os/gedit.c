#include <stdio.h>
#include <stdlib.h>

void main()
{
  system("gedit &");
}