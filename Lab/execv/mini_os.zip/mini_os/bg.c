#include <stdio.h>

void main()
{
  printf("Background Loading.......\n");
}